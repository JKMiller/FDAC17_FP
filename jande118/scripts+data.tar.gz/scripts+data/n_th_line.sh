#!/bin/bash
line="$2"
file="$1"
sed "${line}q;d" $file
