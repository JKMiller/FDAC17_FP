#!/bin/bash
INPUT="$1"
(cut -d',' -f 2 $INPUT | uniq -c)>$(echo $INPUT.index)
